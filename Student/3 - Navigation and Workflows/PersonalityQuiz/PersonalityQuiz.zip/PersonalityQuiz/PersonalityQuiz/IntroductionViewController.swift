//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Tyler Christensen on 9/30/21.
//

import UIKit

class IntroductionViewController: UIViewController {
    
    @IBAction func unwindtoQuizIntroduction(segue: UIStoryboardSegue) {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

