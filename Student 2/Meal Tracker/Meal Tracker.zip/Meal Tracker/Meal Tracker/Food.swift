//
//  Food.swift
//  Meal Tracker
//
//  Created by Tyler Christensen on 10/11/21.
//

import Foundation

struct Food {
    var name: String
    var description: String
}



