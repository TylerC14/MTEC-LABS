//
//  Meal.swift
//  Meal Tracker
//
//  Created by Tyler Christensen on 10/11/21.
//

import Foundation

struct Meal {
    var name: String
    var food: [Food]
}




